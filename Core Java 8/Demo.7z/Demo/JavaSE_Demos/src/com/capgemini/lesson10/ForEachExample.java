package com.capgemini.lesson10;
/*
 * For Each is also referred as enhanced for loop
 */
public class ForEachExample {
	public static void main(String[] args) {
		 char[] vowels = { 'a', 'e', 'i', 'o', 'u'};
		    
		    for(char ch: vowels){
		      System.out.println(ch);
		    }
	}
}
